from django.apps import AppConfig


class TestworkConfig(AppConfig):
    name = 'testwork'
