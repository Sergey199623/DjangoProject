from django.shortcuts import render


def index(request):
	return render(request, 'testwork/homePage.html') #Основная страница

def contact(request):
	return render(request, 'testwork/contact.html', {'values': ['Если у вас остались вопросы, то задавайте их мне по Email - почте:', 'example@example.com']})